<?php

namespace App\api_models\v1;


use Illuminate\Database\Eloquent\Model;

class DC_Setting extends Model
{
    protected $table="setting";
    public $timestamps=false;
    protected $connection="dc_database";

}
