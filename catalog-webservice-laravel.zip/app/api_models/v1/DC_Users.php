<?php

namespace App\api_models\v1;


use Illuminate\Database\Eloquent\Model;

class DC_Users extends Model
{
    protected $table="users";
    protected $connection="dc_database";

}
