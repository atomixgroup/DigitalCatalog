<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Notification extends Model
{
    protected $table="notification";
    protected $connection="dc_database";
}
