<?php

namespace App\api_models\v1;


use Illuminate\Database\Eloquent\Model;

class DC_Slide extends Model
{
    protected $table="slide";
    protected $connection="dc_database";

}
