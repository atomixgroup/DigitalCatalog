<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Seen extends Model
{
    protected $table="seen";
    protected $connection="dc_database";
}
