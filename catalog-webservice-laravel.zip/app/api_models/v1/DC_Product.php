<?php

namespace App\api_models\v1;


use Illuminate\Database\Eloquent\Model;

class DC_Product extends Model
{
    protected $table="product";
    protected $connection="dc_database";

}
