<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Customer extends Model
{
    protected $table="customer";
    protected $connection="dc_database";
}
