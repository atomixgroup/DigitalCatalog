<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Messages extends Model
{
    protected $table="messages";
    protected $connection="dc_database";
}
