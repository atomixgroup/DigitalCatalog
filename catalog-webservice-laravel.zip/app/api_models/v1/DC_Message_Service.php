<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Message_Service extends Model
{
    protected $table="message_service";
    protected $connection="dc_database";
}
