<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Members extends Model
{
    protected $table="members";
    protected $connection="dc_database";
}
