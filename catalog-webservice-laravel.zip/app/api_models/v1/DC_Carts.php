<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Carts extends Model
{
    protected $table="carts";
    protected $connection="dc_database";
}
