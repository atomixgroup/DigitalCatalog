<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Category extends Model
{
    protected $table="category";
    protected $connection="dc_database";
}
