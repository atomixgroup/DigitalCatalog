<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Rate extends Model
{
    protected $table="rate";
    protected $connection="dc_database";
}
