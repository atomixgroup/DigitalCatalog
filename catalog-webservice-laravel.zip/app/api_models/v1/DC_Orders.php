<?php

namespace App\api_models\v1;

use Illuminate\Database\Eloquent\Model;

class DC_Orders extends Model
{
    protected $table="orders";
    protected $connection="dc_database";
}
