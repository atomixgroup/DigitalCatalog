<?php

namespace App\Http\Controllers\api\v1;


use App\api_models\v1\DC_Carts;
use App\api_models\v1\DC_Messages;
use App\api_models\v1\DC_Product;
use App\api_models\v1\DC_Users;
use App\Http\Controllers\Controller;



use Illuminate\Http\Request;

use SoapClient;


class Controller_Payment extends Controller
{
    private $MerchantID = '477f63ac-db19-11e7-a3e2-005056a205be';
    function setCart(Request $request){
        $carts = json_decode($request->input("carts"));
        $sh2 = $request->input("sh2");
        $user=DC_Users::where("sh2",$sh2)->first();

        $address = $request->input("address");
        $phone = $request->input("phone");
        $postal = $request->input("postal");
        $code = $request->input("code");
        $amount=0;
        $products=array();
        foreach ($carts as $cart){
            $product=DC_Product::where("id",$cart->id)->first()->toArray();
            $products[]=$product;
            $amount+=intval($cart->count)*intval($product['price']);
        }
        $cart=new DC_Carts();
        $cart->amount=$amount/10;
        $cart->u_id=$user['id'];
        $cart->type="cart";
        $cart->region_code=$code;
        $cart->products=json_encode($products);
        $cart->address=$address;
        $cart->postal=$postal;
        $cart->phone=$phone;
        $cart->status="no";
        $cart->save();
        echo $cart['id'];
    }
    function PayRequest(Request $request)
    {
        //Required
        $cart_id = $request->input("id");
        $sh2 = $request->input("sh2");
        $user=DC_Users::where("sh2",$sh2)->first();
        $cart=DC_Carts::where("id",$cart_id)->first();
        $phone = $cart->phone;
        $code = $cart->region_code;
        echo $code;
        $amount=$cart->amount;
//        	amount	u_id	ref_id	authority	type	region_code	products	address	postal	phone	status

        $Description = $code;  // Required
        $Email = 'raminsk8er@gmail.com'; // Optional
        $Mobile = $phone; // Optional
        $CallbackURL = route("payment.back");  // Required

        // URL also can be ir.zarinpal.com or de.zarinpal.com
        $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);

        $result = $client->PaymentRequest([
            'MerchantID' => $this->MerchantID,
            'Amount' => $amount,
            'Description' => $Description,
            'Email' => $Email,
            'Mobile' => $Mobile,
            'CallbackURL' => $CallbackURL,
        ]);
        echo $result->Status;
        //Redirect to URL You can do it also by creating a form
        if ($result->Status == 100) {
            $cart->amount=$amount;
            $cart->u_id=$user['id'];
            $cart->authority=$result->Authority;
            $cart->status="no";
            $cart->save();
            return redirect('https://www.zarinpal.com/pg/StartPay/' . $result->Authority);
        } else {
            echo "مشکل در ارتباط با درگاه به وجود آمده است";
        }

    }
//u_id	message	status	type	value

    function PayBack(Request $request)
    {
        //Amount will be based on Toman
        $Authority = $request->input('Authority');
        $status=$request->input("Status");
        if ($status == 'OK') {
            $cart=DC_Carts::where('authority',$Authority)->first();

            if($cart){
                $Amount = $cart->amount;
                $client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
                $result = $client->PaymentVerification([
                    'MerchantID' => $this->MerchantID,
                    'Authority' => $Authority,
                    'Amount' => $Amount,
                ]);

                if ($result->Status == 100) {
                    $cart->ref_id=$result->RefID;
                    $cart->save();
                    $message=new DC_Messages();
                    $message->u_id=$cart->u_id;
                    $message->status="approved";
                    $message->type="cart";
                    $message->value=$cart['id'];
                    $message->message="مبلغ "+$Amount+" ریال "+"به حساب شما واریز شد.";
                    $message->save();
                    $user=DC_Users::where("id",$cart->u_id)->first();
                    $this->sendSms("یک سفارش برای شما در فروشگاهتان ثبت شده است",$user->phone);
                    return view("transaction")->with("ref",$result->RefID)->with("status","1");
                } else {
                    return view("transaction")->with("status","2");

                }
            }
        } else {
            return view("transaction")->with("status","3");
        }
    }
    private
        $BASE_HTTP_URL = "http://www.sibsms.com/APISend.aspx?";

    public
    function sendSms($message, $number)
    {
        $USERNAME = "09143322996";  // your username (fill it with your username)
        $PASSWORD = "63266741"; // your password (fill it with your password)        $senderNumber = "30007546"; // [FILL] sender number ; which is your 3000xxx number
        $senderNumber = "50002030003888";
        $message = urlencode($message); // [FILL] the content of the message; (in url-encoded format !)

        // creating the url based on the information above
        $url = $this->BASE_HTTP_URL .
            "Username=" . $USERNAME . "&Password=" . $PASSWORD .
            "&From=" . $senderNumber . "&To=" . $number .
            "&Text=" . $message;
        // sending the request via http call
        $result = $this->call($url);
        // Now you can compare the response with 0 or 1
    }

// this method provides a simple way of calling a url
    private
    function call($url)
    {
        return file_get_contents($url);
    }
}
