<?php

namespace App\Http\Controllers\api\v1;


use App\api_models\v1\DC_Members;
use App\api_models\v1\DC_Message_Service;
use App\api_models\v1\DC_Notification;
use App\api_models\v1\DC_Users;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;



class Controller_MessageService extends Controller
{
    private $firebaseUrl='https://fcm.googleapis.com/fcm/send';
    function setToken(Request $request){
        $sh2=$request->input("sh2");
        $token=$request->input("token");
        $user=DC_Users::where("sh2",$sh2)->first();
        $member=new DC_Members();
        $member->u_id=$user['id'];
        $member->firebase_id=$token;
        $member->save();
        echo "OK:0";
    }
    function sendNotif(Request $request){
        $user=$this->checkAutorized($request);
        if($user){
            $api=DC_Message_Service::where("u_id",$user['id'])->first()->web_api;
            $members=DC_Members::where('u_id',$user['id'])->get();
            $firebase_ids=array();
            $ids="";
            $first=true;
            foreach ($members as $member){
                if($first){
                    $ids.=$member['id'];
                }
                else{
                    $ids.=','.$member['id'];
                }
                $firebase_ids[]=$member->firebase_id;
                $first=false;
            }

            $message=$request->input("message");
            $type=$request->input("type");
            $title=$request->input("title");
            $value=$request->input("value");

            $notification=new DC_Notification();
            $notification->message=$message;
            $notification->title=$title;
            $notification->type=$type;
            $notification->val=$value;
            $notification->u_id=$user['id'];
            $notification->save();
            $path = public_path() . "/catalog/images/".$user['id'];

            if (!file_exists($path))
                mkdir($path);
            $data=array (
                "title"=>$title,
                "message"=>$message,
                "type"=>$type,
                "value"=>$value
            );

            if ($request->has("file")) {

                $image_url="$path/notif_image_".$notification['id'].".jpg";
                file_put_contents($image_url, base64_decode($request->input("file")));
                $data['image']=url("api/Catalog/v1/getNotifImage?id=".$notification['id']);
            }
            else{
                $data['image']="";
            }
            $this->sendMessage($data,$firebase_ids,$api);
        }

    }

    private function sendMessage($data,$ids,$api){
        $message = array(
            'registration_ids' => $ids,
            'data' =>array("message"=> json_encode($data))
        ,
        );

        $headers = array (
            'Authorization: key=' . $api,
            'Content-Type: application/json'
        );

        $ch = curl_init ();
        curl_setopt ( $ch, CURLOPT_URL, $this->firebaseUrl );
        curl_setopt ( $ch, CURLOPT_POST, true );
        curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt ( $ch, CURLOPT_POSTFIELDS, json_encode($message) );

        $result = curl_exec ( $ch );
        curl_close ( $ch );
    }
    private function checkAutorized(Request $request)
    {
        $sh1 = $request->input("sh1");
        $sh2 = $request->input("sh2");
        $username = $request->input("username");
        $password = $request->input("password");
        $imei = $request->input("imei");
        $user = DC_Users::where('username', $username)
            ->where('password', $password)
            ->where('sh1', $sh1)
            ->where('sh2', $sh2)
            ->get()->first();
        if ($user) {
            return $user;
        } else {
            return false;
        }
    }
    function getNotifImage(Request $request){
        $id=$request->input("id");
        $notif=DC_Notification::where("id",$id)->first();
        $path = public_path() . "/catalog/images/" . $notif->u_id . "/notif_image_".$id.".jpg";
        $headers = array(
            'Content-Type: application/jpg',
        );
        return response()->download($path,"notif_image_".$id.".jpg", $headers);
    }
}
