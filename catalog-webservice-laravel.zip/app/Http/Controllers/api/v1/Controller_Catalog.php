<?php

namespace App\Http\Controllers\api\v1;


use App\api_models\v1\DC_Carts;
use App\api_models\v1\DC_Category;
use App\api_models\v1\DC_Comment;
use App\api_models\v1\DC_Members;
use App\api_models\v1\DC_Messages;
use App\api_models\v1\DC_Orders;
use App\api_models\v1\DC_Product;
use App\api_models\v1\DC_Seen;
use App\api_models\v1\DC_Rate;
use App\api_models\v1\DC_Setting;
use App\api_models\v1\DC_Slide;
use App\api_models\v1\DC_Users;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use ZipArchive;

class Controller_Catalog extends Controller
{

    function loginSet(Request $request)
    {
        $username = $request->input("username");
        $password = $request->input("password");
        $sh2 = $request->input("sh2");

        $user = DC_Users::where("username", $username)->where("password", $password)
            ->where("sh2", $sh2)->get()->first();
        if ($user) {
            $code = rand(1001, 9999);
            $user->active_code = $code;
            $user->save();
            $this->sendActivationSms($user, $code);
            return response("OK:1");
        } else {
            return response("ERROR:0");
        }

    }

    public function setActive(Request $request)
    {
        $code = $request->input("code");
        $sh2 = $request->input("sh2");
        $user = DC_Users::where('active_code', $code)->where('sh2', $sh2)->get()->first();
        if ($user) {
            if ($request->has("token")) {
                $inputToken = $request->input("token");
                if ($user->token != '' and $user->token != null) {
                    $tokens = json_decode($user->token);
                    $flag = false;
                    if (is_array($tokens) and count($tokens) > 0) {
                        foreach ($tokens as $token) {
                            if ($token == $inputToken) {
                                $flag = true;
                            }
                        }
                    }
                    if (!$flag) {
                        $tokens[] = $inputToken;
                        $user->token = json_encode($tokens);
                        $user->save();
                    }
                }
                else{
                    $tokens=array();
                    $tokens[]=$inputToken;
                    $user->token = json_encode($tokens);
                    $user->save();
                }
            }
            return response($user->sh1);
        } else {
            return response("ERROR:0");
        }
    }

    public function getAllData(Request $request)
    {
        //$user = $this->checkAutorized($request);
        $sh2 = $request->input("sh2");
        $user = DC_Users::where("sh2", $sh2)->get()->first();
        if ($user) {
            $products = DC_Product::where("u_id", $user['id'])->orderBy('id', 'desc')->get()->toArray();
            $categories = DC_Category::where("u_id", $user['id'])->orderBy('id', 'desc')->get()->toArray();
            $settings = DC_Setting::where("u_id", $user['id'])->orderBy('id', 'desc')->first()->toArray();
            $slides = DC_Slide::where("u_id", $user['id'])->orderBy('id', 'desc')->get()->toArray();

            $dataProducts = array();
            foreach ($products as $product) {
                $product['update_token'] = "" . strtotime($product['updated_at']);
                $seen=DC_Seen::where("p_id",$product['id'])->count();
                $product['seen']=$seen;
                $dataProducts[] = $product;
            }
            $dataCategories = array();
            foreach ($categories as $category) {
                $category['update_token'] = "" . strtotime($category['updated_at']);
                $dataCategories[] = $category;
            }
            $dataSlides = array();
            foreach ($slides as $slide) {
                $slide['update_token'] = "" . strtotime($slide['updated_at']);
                $dataSlides[] = $slide;
            }
            $data = array(
                $dataProducts,
                $dataCategories,
                $dataSlides,
                $settings
            );
            return response()->json($data);
        } else {
            return response("ERROR:0");
        }
    }

    public function getAllData2(Request $request)
    {
        //$user = $this->checkAutorized($request);
        $sh2 = $request->input("sh2");
        $user = DC_Users::where("sh2", $sh2)->get()->first();
        if ($user) {
            $products = DC_Product::where("u_id", $user['id'])->orderBy('id', 'desc')->get()->toArray();
            $categories = DC_Category::where("u_id", $user['id'])->orderBy('id', 'desc')->get()->toArray();
            $settings = DC_Setting::where("u_id", $user['id'])->orderBy('id', 'desc')->first()->toArray();
            $slides = DC_Slide::where("u_id", $user['id'])->orderBy('id', 'desc')->get()->toArray();

            $dataProducts = array();
            foreach ($products as $product) {
                $product['update_token'] = "" . strtotime($product['updated_at']);
                $dataProducts[] = $product;
            }
            $dataCategories = array();
            foreach ($categories as $category) {
                $category['update_token'] = "" . strtotime($category['updated_at']);
                $dataCategories[] = $category;
            }
            $dataSlides = array();
            foreach ($slides as $slide) {
                $slide['update_token'] = "" . strtotime($slide['updated_at']);
                $dataSlides[] = $slide;
            }
            $data = array(
                $dataProducts,
                $dataCategories,
                $dataSlides,
                $settings
            );
            return response()->json($data);
        } else {
            return response("ERROR:0");
        }
    }

    public function setComment(Request $request)
    {
        $user = DC_Users::where("sh2", $request->input("sh2"))->first();
        if ($user) {
            $comment = new DC_Comment();
            $comment->text = $request->input("text");
            $comment->owner_name = $request->input("owner_name");
            $comment->p_id = $request->input("id");
            $comment->save();

            $api = DC_Message_Service::where("u_id", $user['id'])->first()->web_api;
            $firebase_ids = array();
            if (isset($user->token)) {
                $tokens = json_decode($user->token);
                foreach ($tokens as $token) {
                    $firebase_ids[] = $token;
                }

                $message = $request->input("text");
                $type = "product";
                $title = "یکی از کاربران نظری ثبت کرده است";
                $value = $request->input("id");

                $data = array(
                    "title" => $title,
                    "message" => $message,
                    "type" => $type,
                    "value" => $value,
                    "image" => ""
                );
                $this->sendMessage($data, $firebase_ids, $api);
            }
        }
    }

    private
    function sendMessage($data, $ids, $api)
    {
        $message = array(
            'registration_ids' => $ids,
            'data' => array("message" => json_encode($data))
        ,
        );

        $headers = array(
            'Authorization: key=' . $api,
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($message));

        $result = curl_exec($ch);
        curl_close($ch);
    }

    public
    function getComments(Request $request)
    {
        $user = DC_Users::where("sh2", $request->input("sh2"))->first();
        if ($user) {
            $comments = DC_Comment::where("p_id", $request->input("id"))->get()->toArray();
            if (count($comments) > 0) {
                echo json_encode($comments);
            } else {
                echo "no.record";
            }
        }
    }

    public
    function deleteComment(Request $request)
    {
        $user = $this->checkAutorized($request);
        if ($user) {
            $comment = DC_Comment::where("id", $request->input("id"))->first();
            $comment->delete();

        }
    }

    public
    function storeCategory(Request $request)
    {
        $user = $this->checkAutorized($request);

        if ($user) {
            $title = $request->input("title");
            $description = $request->input("description");
            $user_id = $user->id;
            $id = $request->input("id");
            if ($id != -1 and $id != "-1") {
                $category = DC_Category::where("id", $id)->get()->first();
                if (!$category) {
                    echo "ERROR:1";
                    return;
                }
            } else {
                $category = new DC_Category();
            }
            $category->title = $title;
            $category->description = $description;
             if ($request->has("section")) {
                $category->section = $request->input("section");
            }
            $category->u_id = $user_id;
            $category->save();
            $id = $category['id'];

            $path = public_path() . "/catalog/images/$user_id";
            if (!file_exists($path))
                mkdir($path);
            $path .= "/$id";
            if (!file_exists($path))
                mkdir($path);

            if ($request->has("primary")) {
                file_put_contents("$path/primary.jpg", base64_decode($request->input("primary")));
            }
            return response("OK:1");
        } else {
            return response("ERROR:0");
        }
    }

    public
    function getFile(Request $request)
    {
        if ($request->has("sh2", "id")) {
            $sh2 = $request->input("sh2");
            $id = $request->input("id");
            $product = DC_Product::where("id", $id)->first();
            $user = DC_Users::where("sh2", $sh2)->first();
            $path = public_path() . "/catalog/images/" . $user['id'] . "/" . $product->cat_id . "/$id/file/" . $product->link;


            $headers = array(
                'Content-Type: application/file',
            );
            return response()->download($path, $product->link, $headers);
        } else {
            echo "ERROR:0";
        }
    }

    public
    function storeProduct(Request $request)
    {

        $user = $this->checkAutorized($request);

        if ($user) {
            $link = $request->input("link");
            $video = $request->input("video");
            $video_url = $request->input("video_url");
            $video_thumb = $request->input("video_thumb");
            $type = $request->input("type");
            $download = $request->input("download");
            $price = $request->input("price");
            if ($price == "" or $price == " " or empty($price)) {
                $price = 0;
            }
            $title = base64_decode($request->input("title"));
            $description = base64_decode($request->input("description"));
            $top = $request->input("top");
            $cat_id = json_decode($request->input("cat_id"));
            $user_id = $user->id;
            $id = $request->input("id");
            if ($id != -1 and $id != "-1") {
                $product = DC_Product::where("id", $id)->get()->first();
                if (!$product) {
                    echo "ERROR:1";
                    return;
                }
                $isNew = "no";

            } else {
                $isNew = "yes";
                $product = new DC_Product();
            }
            $product->video = $video;
            $product->video_url = $video_url;
            $product->video_thumb = $video_thumb;
            $product->type = $type;
            $product->link = $link;
            $product->download = $download;
            $product->price = $price;
            $product->title = $title;
            $product->top = $top;
            $product->description = $description;
            $product->cat_id = $cat_id;
            $product->u_id = $user_id;
            $product->cat_id = $cat_id;
            $product->save();
            $id = $product['id'];

            $path = public_path() . "/catalog/images/$user_id";
            if (!file_exists($path))
                mkdir($path);
            $path .= "/$cat_id";
            if (!file_exists($path))
                mkdir($path);
            $path .= "/$id";
            if (!file_exists($path))
                mkdir($path);

            if ($request->hasFile('file_param')) {
                $image = $request->file('file_param');
                $fileName = $image->getClientOriginalName();
                $imageUrl = 'images/uploads/' . $fileName;
                $image->move($path, $fileName);
                $zip = new ZipArchive;
                $zip->open("$path/$fileName");
                $zip->extractTo($path);
                $zip->close();
                unlink("$path/$fileName");
                if ($link != "") {
                    if (!file_exists($path . "/file"))
                        mkdir($path . "/file");
                    rename($path . "/$link", $path . "/file/$link");
                }
            } else {
                if ($request->has("primary")) {
                    file_put_contents("$path/primary.jpg", base64_decode($request->input("primary")));
                }
                if ($request->has("p1")) {
                    file_put_contents("$path/p1.jpg", base64_decode($request->input("p1")));
                }
                if ($request->has("p2")) {

                    file_put_contents("$path/p2.jpg", base64_decode($request->input("p2")));

                }
                if ($request->has("p3")) {
                    file_put_contents("$path/p3.jpg", base64_decode($request->input("p3")));
                }
                if ($request->has("p4")) {
                    file_put_contents("$path/p4.jpg", base64_decode($request->input("p4")));

                }
                if ($request->has("p5")) {

                    file_put_contents("$path/p5.jpg", base64_decode($request->input("p5")));

                }
                if ($request->has("p6")) {

                    file_put_contents("$path/p6.jpg", base64_decode($request->input("p6")));

                }
            }

            return response("OK:1");
        } else {
            return response("ERROR:0");
        }


    }

    function getUpdate(Request $request)
    {
        $sh2 = $request->input("sh2");
        $user = DC_Users::where("sh2", $sh2)->first();
        $setting = DC_Setting::where("u_id", $user['id'])->first();
        $file = public_path() . "/catalog/images/" . $user['id'] . "/program.apk";
        $headers = array(
            'Content-Type: application/apk',
        );
        $name = str_replace(" ", "_", $setting->title) . ".apk";
        return response()->download($file, $name, $headers);

    }

    function checkUpdate(Request $request)
    {
        $sh2 = $request->input("sh2");
        $user = DC_Users::where("sh2", $sh2)->first();
        $setting = DC_Setting::where("u_id", $user['id'])->first();
        echo $setting->version;

    }

    function storeAbout(Request $request)
    {
        $user = $this->checkAutorized($request);
        if ($user) {
            $description = $request->input("description");
            if ($request->has("primary")) {
                $path = public_path() . "/catalog/images/" . $user['id'];
                if (!file_exists($path))
                    mkdir($path);
                file_put_contents("$path/about.jpg", base64_decode($request->input("primary")));
            }
            $setting = DC_Setting::where("u_id", $user['id'])->get()->first();
            if ($setting) {
                $setting->about = $description;
                $setting->save();
            } else {
                $setting = new DC_Setting();
                $setting->u_id = $user['id'];
                $setting->about = $description;
                $setting->save();
            }
            echo "OK:1";
        } else {
            echo "ERROR:0";
        }
    }

    function getAboutImage(Request $request)
    {
        if ($request->has("sh2")) {
            $sh2 = $request->input("sh2");
            $user = DC_Users::where("sh2", $sh2)->first();
            $file = public_path() . "/catalog/images/" . $user['id'] . "/about" . ".jpg";
            $headers = array(
                'Content-Type: application/image',
            );
            return response()->download($file, "about.jpg", $headers);
        } else {
            echo "ERROR:0";
        }
    }

    function storeSettings(Request $request)
    {
        $user = $this->checkAutorized($request);
        if ($user) {
            $u_id = $user['id'];
            $p_color = $request->input("primary_color");
            $s_color = $request->input("second_color");
            $title = $request->input("title");
            $description = $request->input("description");
            $phone = $request->input("phone");
            $instagram = $request->input("instagram");
            $telegram = $request->input("telegram");
            $linkedin = $request->input("linkedin");
            $is_cart = $request->input("is_cart");

            $path = public_path() . "/catalog/images/$u_id";
            if (!file_exists($path))
                mkdir($path);
            $path .= "/pdf";
            if (!file_exists($path))
                mkdir($path);

            if ($request->has("pdf")) {
                file_put_contents("$path/list_gheymat.pdf", base64_decode($request->input("pdf")));
            }
            $setting = DC_Setting::where("u_id", $u_id)->get()->first();
            if (!$setting) {
                $setting = new DC_Setting();
                $setting->u_id = $u_id;
            }
            $setting->instagram = $instagram;
            $setting->telegram = $telegram;
            $setting->linkedin = $linkedin;
            $setting->title = $title;
            $setting->description = $description;
            $setting->primary_color = $p_color;
            $setting->second_color = $s_color;
            $setting->phone = $phone;
            $setting->is_cart = $is_cart;
            $setting->save();
            echo "OK:1";
        } else {
            echo "ERROR:0";
        }
    }

////////////////////////////
///  Private Methods
////////////////////////////
    private
    function sendActivationSms($user, $code)
    {

        $phone = $user->phone;
        $this->sendSms($code, $phone);
        //todo set sms panel codes
    }

    private
    function hashString($string)
    {
        return md5(hash("sh256", md5("Nmrpk7D/u8q2kW0vT+eea4txwexkq0uMVQ2F0b4mZM")));
    }

    private
    function generateSecureHash()
    {
        return md5(hash("sh256", md5(time() . "Nmrpk7D/u8q2kW0vT+eea4txwexkq0uMVQ2F0b4mZM" . rand(1, 19623123))));
    }

    private
    function checkAutorized(Request $request)
    {
        $sh1 = $request->input("sh1");
        $sh2 = $request->input("sh2");
        $username = $request->input("username");
        $password = $request->input("password");
        $imei = $request->input("imei");
        $user = DC_Users::where('username', $username)
            ->where('password', $password)
            ->where('sh1', $sh1)
            ->where('sh2', $sh2)
            ->get()->first();
        if ($user) {
            return $user;
        } else {
            return false;
        }
    }

    function removeProduct(Request $request)
    {
        $id = $request->input("id");
        $user = $this->checkAutorized($request);
        if ($user) {
            $product = DC_Product::find($id);
            if ($product->u_id == $user->id) {
                $product->delete();
                echo "OK:1";
            } else {
                echo "ERROR:-1";
            }
        } else {
            echo "ERROR:0";
        }
    }

    function removeCategory(Request $request)
    {
        $id = $request->input("id");
        $user = $this->checkAutorized($request);
        if ($user) {
            $category = DC_Category::find($id);
            if ($category->u_id == $user->id) {
                $category->delete();
                echo "OK:1";
            } else {
                echo "ERROR:-1";
            }
        } else {
            echo "ERROR:0";
        }
    }

    function getImage(Request $request)
    {
        $name = $request->input("name");
        $id = $request->input("id");

        $product = DC_Product::where("id", $id)->get()->first();
        $cat = $product->cat_id;
        $id = $product['id'];
        $user_id = $product->u_id;
        if ($product) {
            $file = public_path() . "/catalog/images/$user_id/$cat/$id/" . $name . ".jpg";

            $headers = array(
                'Content-Type: application/image',
            );
            return response()->download($file, $name, $headers);
        }

    }



    function getCatImage(Request $request)
    {
        $id = $request->input("id");

        $category = DC_Category::where("id", $id)->get()->first();

        $id = $category['id'];
        $user_id = $category->u_id;
        if ($category) {
            $file = public_path() . "/catalog/images/$user_id/$id/primary.jpg";
            $headers = array(
                'Content-Type: application/image',
            );
            return response()->download($file, "primary", $headers);
        }

    }

    function getSlideImage(Request $request)
    {
        $id = $request->input("id");

        $slide = DC_Slide::where("id", $id)->get()->first();

        $id = $slide['id'];
        $user_id = $slide->u_id;
        if ($slide) {
            $file = public_path() . "/catalog/images/$user_id/slider/$id.jpg";
            $headers = array(
                'Content-Type: application/image',
            );
            return response()->download($file, "$id", $headers);
        }

    }
    public
    function storeSlide(Request $request)
    {
        $user = $this->checkAutorized($request);

        if ($user) {
            $link = $request->input("link");

            $user_id = $user->id;
            $id = $request->input("id");
            if ($id != -1 and $id != "-1") {
                $slide = DC_Slide::where("id", $id)->get()->first();
                if (!$slide) {
                    echo "ERROR:1";
                    return;
                }
            } else {
                $slide = new DC_Slide();
            }
            if($request->has("title")){
                $slide->title = $request->input("title");
            }
             if($request->has("tab_title")){
            
                $slide->tab_title = $request->input("tab_title");
            }
            $slide->link = $link;
            $slide->u_id = $user_id;
            $slide->save();
            $id = $slide['id'];

            $path = public_path() . "/catalog/images/$user_id";
            if (!file_exists($path))
                mkdir($path);
            $path .= "/slider";
            if (!file_exists($path))
                mkdir($path);

            if ($request->has("image")) {
                file_put_contents("$path/$id.jpg", base64_decode($request->input("image")));
            }
            return response("OK:1");
        } else {
            return response("ERROR:0");
        }
    }

    function storePdf(Request $request)
    {
        $user = $this->checkAutorized($request);

        if ($user) {
            $user_id = $user['id'];
            $path = public_path() . "/catalog/images/$user_id";
            if (!file_exists($path))
                mkdir($path);
            $path .= "/pdf";
            if (!file_exists($path))
                mkdir($path);

            if ($request->has("pdf")) {
                file_put_contents("$path/list_gheymat.pdf", base64_decode($request->input("pdf")));
            }
            echo "OK:1";
        } else {
            echo "ERROR:0";
        }
    }

    function getPdf(Request $request)
    {
        $sh2 = $request->input("sh2");

        $user = DC_Users::where("sh2", $sh2)->first();
        if ($user) {
            $user_id = $user['id'];

            $file = public_path() . "/catalog/images/$user_id/pdf/list_gheymat.pdf";
            $headers = array(
                'Content-Type: application/pdf',
            );
            return response()->download($file, "list_gheymat.pdf", $headers);
        }
        echo "ERROR:0";
    }

    function setOrder(Request $request)
    {
        $user = DC_Users::where("sh2", $request->input("sh2"))->first();
        if ($user) {
            $u_id = $user['id'];
            if ($request->has(["cat_id", "id"])) {
                $id = $request->input("id");
                $address = $request->input("address");
                $name = $request->input("name");
                $phone = $request->input("phone");
                $postal = $request->input("postal");
                $count = $request->input("count");
                $cat_id = $request->input("cat_id");

                $product = DC_Product::where("id", $id)->first();
                $category = DC_Category::where("id", $cat_id)->first();

                if ($product) {
                    $order = new DC_Orders();
                    $order->u_id = $u_id;
                    $order->product = $product->title;
                    $order->category = $category->title;
                    $order->p_id = $product['id'];
                    $order->address = $address;
                    $order->name = $name;
                    $order->phone = $phone;
                    $order->postal = $postal;
                    $order->count = $count;
                    $order->save();
                    $this->sendSms("سفارشی برای فروشگاه شما ثبت شده است", $user->phone);
                    echo "OK:1";
                } else {
                    echo "ERROR:2";
                }
            } else {
                echo "ERROR:1";
            }
        } else {
            echo "ERROR:0";
        }
    }

    function setRate(Request $request)
    {
        if ($request->has(["sh2", "IMEI", "rate"])) {
            $sh2 = $request->input("sh2");
            $IMEI = $request->input("IMEI");
            $rate = intval($request->input("rate"));
            $id = $request->input("id");
            $user = DC_Users::where("sh2", $sh2)->first();
            if ($user) {
                if ($rate > 5) {
                    $rate = 5;
                } elseif ($rate < 1) {
                    $rate = 1;
                }
                $rateModel = DC_Rate::where("p_id", $id)->where("IMEI", $IMEI)->where("u_id", $user['id'])->first();
                if ($rateModel) {
                    $rateModel->rate = $rate;
                    $rateModel->save();
                } else {
                    $rateModel = new DC_Rate();
                    $rateModel->u_id = $user['id'];
                    $rateModel->p_id = $id;
                    $rateModel->rate = $rate;
                    $rateModel->IMEI = $IMEI;
                    $rateModel->save();
                }
                echo "OK:1";
            } else {
                echo "ERROR:1";
            }
        } else {
            echo "ERROR:0";
        }
    }

    function getAverage(Request $request)
    {
        if ($request->has(["sh2", "id"])) {
            $sh2 = $request->input("sh2");
            $id = $request->input("id");
            $user = DC_Users::where("sh2", $sh2)->first();
            if ($user) {
                $rates = DC_Rate::where("p_id", $id)->where("u_id", $user['id'])->get();
                $sum = 0;
                if (count($rates) > 0) {
                    foreach ($rates as $rate) {
                        $sum += $rate->rate;
                    }
                    $avrage = $sum / count($rates);
                    echo $avrage;
                } else {
                    echo "0";
                }
            } else {
                echo "-1";
            }
        } else {
            echo "-2";
        }
    }

    function getMessages(Request $request)
    {
        $user = $this->checkAutorized($request);
        if ($user) {
            $messages = DC_Messages::where("u_id", $user['id'])->get()->toArray();
            return json_encode($messages);
        } else {
            return "ERROR:0";
        }
    }

    function setStatusToChecked(Request $request)
    {
        $user = $this->checkAutorized($request);
        if ($user) {
            $message = DC_Messages::where("id", $request->input("id"))->get()->first();
            $message->status = "checked";
            $message->save();
            echo "OK:1";
            return;
        } else {
            echo "ERROR:0";
        }
    }

    function getMessageDetail(Request $request)
    {
        $user = $this->checkAutorized($request);
        if ($user) {
            $message = DC_Messages::where("id", $request->input("id"))->get()->first();
            if ($message->type == "cart") {
                $cart = DC_Carts::where("id", $message->value)->get()->first()->toArray();
                echo json_encode($cart);
                return;
            }

        }
    }

    private
        $BASE_HTTP_URL = "http://www.sibsms.com/APISend.aspx?";

    function sms(Request $request)
    {
        $this->sendSms("test", "09308144474");
    }

    public
    function sendSms($message, $number)
    {
        $USERNAME = "09143322996";  // your username (fill it with your username)
        $PASSWORD = "63266741"; // your password (fill it with your password)        $senderNumber = "30007546"; // [FILL] sender number ; which is your 3000xxx number
        $senderNumber = "50002030003888";
        $message = urlencode($message); // [FILL] the content of the message; (in url-encoded format !)

        // creating the url based on the information above
        $url = $this->BASE_HTTP_URL .
            "Username=" . $USERNAME . "&Password=" . $PASSWORD .
            "&From=" . $senderNumber . "&To=" . $number .
            "&Text=" . $message;
        // sending the request via http call
        $result = $this->call($url);
        // Now you can compare the response with 0 or 1
    }

// this method provides a simple way of calling a url
    private
    function call($url)
    {
        $user_agent='Mozilla/5.0 (Windows NT 6.1; rv:8.0) Gecko/20100101 Firefox/8.0';

        $options = array(

            CURLOPT_CUSTOMREQUEST  =>"GET",        //set request type post or get
            CURLOPT_POST           =>false,        //set to GET
            CURLOPT_USERAGENT      => $user_agent, //set user agent
            CURLOPT_COOKIEFILE     =>"cookie.txt", //set cookie file
            CURLOPT_COOKIEJAR      =>"cookie.txt", //set cookie jar
            CURLOPT_RETURNTRANSFER => true,     // return web page
            CURLOPT_HEADER         => false,    // don't return headers
            CURLOPT_FOLLOWLOCATION => true,     // follow redirects
            CURLOPT_ENCODING       => "",       // handle all encodings
            CURLOPT_AUTOREFERER    => true,     // set referer on redirect
            CURLOPT_CONNECTTIMEOUT => 120,      // timeout on connect
            CURLOPT_TIMEOUT        => 500,      // timeout on response
            CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
        );

        $ch      = curl_init( $url );

        curl_setopt_array( $ch, $options );
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $content = curl_exec( $ch );
        $err     = curl_errno( $ch );
        $errmsg  = curl_error( $ch );
        $header  = curl_getinfo( $ch );
        curl_close( $ch );

        $header['errno']   = $err;
        $header['errmsg']  = $errmsg;
        $header['content'] = $content;
        return $content;
    }

    function getStatistics(Request $request)
    {
        $user = $this->checkAutorized($request);
        if ($user) {
            $members = DC_Members::where("u_id", $user['id'])->get()->toArray();
            return response(count($members));

        }
    }

    function processVideo(Request $request)
    {
        $url = $request->input("url");
        $sh2 = $request->input("sh2");
        $user = DC_Users::where("sh2", $sh2)->first();
        if ($user) {
            echo $this->getAparatVideoUrl($url);
        }
    }

    private
    function getAparatVideoUrl($code)
    {
        $code = substr($code, strpos($code, "https://"));
        $code = substr($code, 0, strpos($code, '">'));
        $f1 = file_get_contents($code);

        $link = substr($f1, strpos($f1, "newiframe.setAttribute('src','https://"));
        $link = substr($link, 0, strpos($link, "');"));
        $link = substr($link, strpos($link, "https"));
        $f2 = file_get_contents($link);
        $image = substr($f2, strpos($f2, "url('https:") + 5);
        $image = substr($image, 0, strpos($image, "')"));
        $link2 = substr($f2, strpos($f2, "changeFrameSrc()"));
        $link2 = substr($link2, 0, strpos($link2, "}"));
        $link2 = substr($link2, strpos($link2, "https"));
        $link2 = substr($link2, 0, strpos($link2, "';"));
        $f3 = file_get_contents($link2);
        $link2 = substr($f3, strpos($f3, "JSON.parse('") + 4);
        $link2 = substr($link2, strpos($link2, "JSON.parse('") + 12);
        $link2 = substr($link2, 0, strpos($link2, "]]');") + 2);
        $data = json_decode($link2);
        $video = "";
        foreach ($data as $item) {
            foreach ($item as $subitem) {
                if ($subitem->label == "360p") {
                    $video = $subitem->file;
                    break;
                }
            }
            break;
        }
        return $video . "," . $image;
    }
    public function getAboutDesignerImage(){
        $file = public_path() . "/catalog/about.jpg";
        $headers = array(
            'Content-Type: application/pdf',
        );
        return response()->download($file, "about.jpg", $headers);
    }
    public function getAboutDesigner(){
        echo  file_get_contents(public_path() . "/catalog/about.txt");
    }
    function setSeen(Request $request){
        $token=$request->input("token");
        $p_id=$request->input("p_id");
        $sh2 = $request->input("sh2");
        $user = DC_Users::where("sh2", $sh2)->get()->first();
        if ($user) {
            $member=DC_Members::where("firebase_id",$token)->first();
            if($member){
                $m_id=$member['id'];
                $seen=DC_Seen::where("p_id",$p_id)->where("m_id",$m_id)->first();
                if(!$seen){
                    $seen=new DC_Seen();
                    $seen->p_id=$p_id;
                    $seen->m_id=$m_id;
                    $seen->save();
                }
            }
        }

    }
}
