<?php


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::group(['prefix' => 'Catalog/v1'], function () {
    Route::post("/checkUpdate", 'api\v1\Controller_Catalog@checkUpdate');
    Route::get("/getUpdate", 'api\v1\Controller_Catalog@getUpdate');
    Route::post("/getAllData", 'api\v1\Controller_Catalog@getAllData');
    Route::get("/getAllData", 'api\v1\Controller_Catalog@getAllData');
    Route::post("/getAllData2", 'api\v1\Controller_Catalog@getAllData2');
    Route::post("/removeProduct", 'api\v1\Controller_Catalog@removeProduct');
    Route::post("/activation", 'api\v1\Controller_Catalog@setActive');
    Route::post("/saveCategory", 'api\v1\Controller_Catalog@storeCategory');
    Route::post("/saveSlide", 'api\v1\Controller_Catalog@storeSlide');
    Route::post("/saveProduct", 'api\v1\Controller_Catalog@storeProduct');
    Route::post("/savePdf", 'api\v1\Controller_Catalog@storePdf');
    Route::post("/saveSettings", 'api\v1\Controller_Catalog@storeSettings');
    Route::post("/saveAbout", 'api\v1\Controller_Catalog@storeAbout');
    Route::post("/login", 'api\v1\Controller_Catalog@loginSet');
    Route::get("/getImage", 'api\v1\Controller_Catalog@getImage');
    Route::get("/getSlideImage", 'api\v1\Controller_Catalog@getSlideImage');
    Route::get("/getCatImage", 'api\v1\Controller_Catalog@getCatImage');
    Route::get("/getAboutImage", 'api\v1\Controller_Catalog@getAboutImage');
    Route::get("/getPdf", 'api\v1\Controller_Catalog@getPdf');
    Route::get("/getFile", 'api\v1\Controller_Catalog@getFile');
    Route::post("/getAverage", 'api\v1\Controller_Catalog@getAverage');
    Route::post("/getMessages", 'api\v1\Controller_Catalog@getMessages');
    Route::post("/setStatusToChecked", 'api\v1\Controller_Catalog@setStatusToChecked');
    Route::post("/getMessageDetail", 'api\v1\Controller_Catalog@getMessageDetail');
    Route::post("/removeCategory", 'api\v1\Controller_Catalog@removeCategory');
    Route::post("/saveOrder", 'api\v1\Controller_Catalog@setOrder');
    Route::post("/saveRate", 'api\v1\Controller_Catalog@setRate');
    Route::post("/saveCart", 'api\v1\Controller_Payment@setCart');
    Route::post("/saveComment", 'api\v1\Controller_Catalog@setComment');
    Route::post("/getComments", 'api\v1\Controller_Catalog@getComments');
    Route::post("/deleteComment", 'api\v1\Controller_Catalog@deleteComment');
    Route::get("/request", ['as' => 'payment.request', 'uses' => 'api\v1\Controller_Payment@PayRequest']);
    Route::get("/back", ['as' => 'payment.back', 'uses' => 'api\v1\Controller_Payment@PayBack']);
    Route::post("/sendNotif", 'api\v1\Controller_MessageService@sendNotif');
    Route::get("/getNotifImage", 'api\v1\Controller_MessageService@getNotifImage');
    Route::post("/getStatistics", 'api\v1\Controller_Catalog@getStatistics');
    Route::post("/setToken", 'api\v1\Controller_MessageService@setToken');
    Route::post("/processVideo", 'api\v1\Controller_Catalog@processVideo');
    Route::post("/saveSeen", 'api\v1\Controller_Catalog@setSeen');
});

